package org.capgemini;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class EmployeeServiceImplementationTest {

    @Autowired
    private  EmployeeService service;

    @MockBean
    private EmployeeRepository repository;


    @BeforeEach
    void setUp() {
        Employee employee = new Employee(1L,"abisheks","Development");
        Mockito.when(repository.save(Mockito.any(Employee.class))).thenReturn(employee);
        Mockito.when(repository.findById(1L)).thenReturn(Optional.of(employee));
    }

    @Test
    void addEmployee() {
        Employee employee = new Employee(1L,"abisheks","Development");
        assertEquals("Development",service.addEmployee(employee).getDepartment());
    }

    @Test
    void showAllEmployee() throws Exception {
        assertInstanceOf(Employee.class,service.showAllEmployee(1L));
    }

    @Test
    void updateDepartment() throws EmployeeNotFoundException {
        Employee employee = new Employee(1L,"abisheks","Support");
        assertEquals("Development",service.updateDepartment("Development",1L).getDepartment());
    }

}