package org.capgemini;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.junit.jupiter.api.Assertions.*;

@WebMvcTest(EmployeeController.class)
class EmployeeControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EmployeeService service;

    private Employee employee;

    @BeforeEach
    void setUp() {
        employee = new Employee(1L,"abisheks","Development");
    }

    @Test
    void addEmployee() throws Exception {
        Mockito.when(service.addEmployee(Mockito.any(Employee.class))).thenReturn(employee);
        mvc.perform(MockMvcRequestBuilders.post("/add")
                    .contentType(MediaType.APPLICATION_JSON)
                .content("{\n" +
                        "    \"employeeName\":\"abisheks\",\n" +
                        "    \"department\":\"Development\"\n" +
                        "}")).andExpect(MockMvcResultMatchers.status().isOk());

    }

    @Test
    void showAllEmployees() throws Exception {
        Mockito.when(service.showAllEmployee(1L)).thenReturn(employee);
        mvc.perform(MockMvcRequestBuilders.get("/showAll/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.jsonPath("$.department")
                        .value("Development"));

    }
}