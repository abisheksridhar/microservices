package org.capgemini;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.mock.mockito.MockBean;

import javax.persistence.Access;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class EmployeeRepositoryTest {

    @Autowired
    private EmployeeRepository repository;

    @MockBean
    private TestEntityManager entityManager;

    @BeforeEach
    void setUp() {
        Employee employee = new Employee(1L,"abisheks","Support");
        entityManager.persist(employee);
    }

    @Test
    void saveTest()
    {
        Employee employee = new Employee(1L,"abisheks","Support");
        assertEquals("abisheks",repository.save(employee).getEmployeeName());
    }

    @Test
    void findByIdTest()
    {
        assertInstanceOf(Optional.class,repository.findById(1L));
    }
}